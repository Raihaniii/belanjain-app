/**
 * Entry point siap produksi untuk Arenhost.id (cPanel Setup Node.js App / CloudLinux Passenger / VPS)
 * Kompatibel Node.js 18, 20, dan 22 tanpa butuh build ulang di server.
 */
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  createInitialPlatformState,
  createTopUpRequest,
  confirmTopUpSuccess,
  executeTransfer,
  createCheckoutOrder,
  completeOrderAndReleaseSeller,
  refundOrderToWallet,
  requestSellerWithdraw,
  processWithdrawalAdmin,
  adminAdjustWallet,
  verifyWalletPin,
} from "./dist/lib/wallet-engine.js";
import { CATEGORIES } from "./dist/data/categories.js";
import { BRANDS } from "./dist/data/brands.js";
import { REVIEWS } from "./dist/data/reviews.js";
import { PROMOS } from "./dist/data/promos.js";
import { COUPONS } from "./dist/data/coupons.js";
import { BANNERS } from "./dist/data/banners.js";
import { SHIPPING_METHODS } from "./dist/data/shipping-methods.js";
import { PAYMENT_METHODS } from "./dist/data/payment-methods.js";
import { TESTIMONIALS, FAQS } from "./dist/data/faqs.js";
import { initDatabase, saveDatabaseState, getDbMode } from "./dist/lib/mysql-db.js";
import { APP_STYLES } from "./dist/views/styles.js";
import { CLIENT_STOREFRONT_JS } from "./dist/views/client-storefront.js";
import { CLIENT_WALLET_JS } from "./dist/views/client-wallet.js";
import { CLIENT_DASHBOARDS_JS } from "./dist/views/client-dashboards.js";

const PORT = Number(process.env.PORT || process.env.SERVER_PORT || 3000);
const HOST = process.env.HOSTNAME || "0.0.0.0";
const state = await initDatabase();

function buildBootstrapPayload() {
  return {
    ...state,
    categories: CATEGORIES,
    brands: BRANDS,
    reviews: REVIEWS,
    promos: PROMOS,
    coupons: COUPONS,
    banners: BANNERS,
    shippingMethods: SHIPPING_METHODS,
    paymentMethods: PAYMENT_METHODS,
    testimonials: TESTIMONIALS,
    faqs: FAQS,
  };
}

function handleApiAction(body) {
  const { action } = body;

  if (action === "CREATE_TOPUP") {
    const r = createTopUpRequest(state, body.userId, body.amount, body.method);
    return r.ok
      ? { ok: true, message: `Tagihan Top-Up ${r.topup.id} berhasil dibuat. Klik Simulasi Sukses untuk menambah saldo.`, state: buildBootstrapPayload() }
      : { ok: false, error: r.error };
  }

  if (action === "CONFIRM_TOPUP") {
    const r = confirmTopUpSuccess(state, body.topupId);
    return r.ok
      ? { ok: true, message: `Top-Up ${r.topup.id} berhasil! Saldo BelanjaPay bertambah Rp ${r.topup.amount.toLocaleString("id-ID")}.`, state: buildBootstrapPayload() }
      : { ok: false, error: r.error };
  }

  if (action === "TRANSFER_WALLET") {
    const r = executeTransfer(state, body.userId, body.recipient, body.amount, body.note, body.pin);
    return r.ok
      ? { ok: true, message: `Transfer Rp ${r.transfer.amount.toLocaleString("id-ID")} ke ${r.transfer.toUserName} berhasil (${r.transfer.id}).`, state: buildBootstrapPayload() }
      : { ok: false, error: r.error };
  }

  if (action === "CHECKOUT_ORDER") {
    const r = createCheckoutOrder(state, body);
    return r.ok
      ? {
          ok: true,
          order: r.order,
          message: `Pesanan #${r.order.id} berhasil dibuat! ${
            r.order.walletPaidAmount > 0
              ? `Saldo terpotong Rp ${r.order.walletPaidAmount.toLocaleString("id-ID")}.`
              : "Menunggu pembayaran."
          }`,
          state: buildBootstrapPayload(),
        }
      : { ok: false, error: r.error };
  }

  if (action === "COMPLETE_ORDER") {
    const r = completeOrderAndReleaseSeller(state, body.orderId);
    return r.ok
      ? { ok: true, message: `Pesanan #${r.order.id} selesai! Saldo penjual dilepas & cashback 2% BelanjaPay dikreditkan.`, state: buildBootstrapPayload() }
      : { ok: false, error: r.error };
  }

  if (action === "REFUND_ORDER") {
    const r = refundOrderToWallet(state, body.orderId);
    return r.ok
      ? { ok: true, message: `Refund #${r.order.id} disetujui! Dana Rp ${r.order.totalAmount.toLocaleString("id-ID")} masuk otomatis ke saldo BelanjaPay.`, state: buildBootstrapPayload() }
      : { ok: false, error: r.error };
  }

  if (action === "REQUEST_WITHDRAW") {
    const r = requestSellerWithdraw(state, body.userId, body.amount, body.bankId, body.pin);
    return r.ok
      ? { ok: true, message: `Pengajuan Withdraw ${r.withdrawal.id} (Rp ${r.withdrawal.amount.toLocaleString("id-ID")}) menunggu persetujuan Admin.`, state: buildBootstrapPayload() }
      : { ok: false, error: r.error };
  }

  if (action === "ADMIN_PROCESS_WITHDRAW") {
    const r = processWithdrawalAdmin(state, body.withdrawalId, body.decision, body.reason);
    return r.ok
      ? { ok: true, message: `Withdraw ${r.withdrawal.id} diperbarui menjadi ${r.withdrawal.status.toUpperCase()}.`, state: buildBootstrapPayload() }
      : { ok: false, error: r.error };
  }

  if (action === "ADMIN_ADJUST_WALLET") {
    const r = adminAdjustWallet(state, body.targetUserId, body.type, body.amount, body.reason, body.adminId);
    return r.ok
      ? { ok: true, message: `Penyesuaian saldo (${r.adjustment.id}) berhasil dicatat di audit log.`, state: buildBootstrapPayload() }
      : { ok: false, error: r.error };
  }

  if (action === "ADMIN_TOGGLE_FREEZE") {
    const w = state.wallets.find((x) => x.userId === body.targetUserId);
    if (!w) return { ok: false, error: "Dompet tidak ditemukan." };
    w.frozen = !w.frozen;
    return { ok: true, message: `Dompet ${w.walletNumber} sekarang berstatus ${w.frozen ? "FROZEN (Dibekukan)" : "AKTIF"}.`, state: buildBootstrapPayload() };
  }

  if (action === "CHANGE_PIN") {
    const check = verifyWalletPin(state, body.userId, body.oldPin);
    if (!check.ok || !check.wallet) return { ok: false, error: check.error };
    if (!/^\d{6}$/.test(String(body.newPin || ""))) return { ok: false, error: "PIN baru wajib 6 digit angka." };
    check.wallet.pinHash = String(body.newPin);
    return { ok: true, message: "PIN 6-digit BelanjaPay berhasil diperbarui.", state: buildBootstrapPayload() };
  }

  if (action === "CHANGE_DAILY_LIMIT") {
    const check = verifyWalletPin(state, body.userId, body.pin);
    if (!check.ok || !check.wallet) return { ok: false, error: check.error };
    check.wallet.limits.daily = Math.max(500000, Math.floor(Number(body.newLimit) || 10000000));
    return { ok: true, message: `Batas limit harian diubah menjadi Rp ${check.wallet.limits.daily.toLocaleString("id-ID")}.`, state: buildBootstrapPayload() };
  }

  if (action === "ADMIN_UPDATE_SETTINGS") {
    state.settings.defaultDailyLimit = Number(body.defaultDailyLimit) || 10000000;
    state.settings.defaultCashbackPercent = Number(body.defaultCashbackPercent) || 2;
    state.settings.globalFreeze = Boolean(body.globalFreeze);
    return { ok: true, message: "Pengaturan kebijakan BelanjaPay berhasil disimpan.", state: buildBootstrapPayload() };
  }

  return { ok: false, error: "Aksi tidak dikenali." };
}

function renderHtmlShell() {
  const json = JSON.stringify(buildBootstrapPayload()).replace(/</g, "\\u003c");
  return `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>BelanjaIn × BelanjaPay — E-Commerce Marketplace &amp; Dompet Digital</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;1,400&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>${APP_STYLES}</style>
</head>
<body>
  <!-- TOAST -->
  <div id="toastBox" style="display:none; position:fixed; bottom:24px; right:24px; z-index:95; max-width:440px; background:var(--color-navy); color:#fff; border:1px solid var(--color-primary); border-radius:10px; padding:0.9rem 1.15rem; box-shadow:var(--shadow-lg);">
    <div style="display:flex; justify-content:space-between; align-items:start; gap:0.85rem; font-size:0.84rem;">
      <span id="toastMsg"></span>
      <button type="button" onclick="document.getElementById('toastBox').style.display='none'" style="background:none; border:0; color:#9CA3AF; cursor:pointer;">✕</button>
    </div>
  </div>

  <!-- 6-DIGIT PIN NUMPAD MODAL -->
  <div id="pinModal" class="modal-backdrop" role="dialog" aria-modal="true" aria-label="Verifikasi PIN BelanjaPay">
    <div class="card" style="max-width:360px; width:100%; padding:1.75rem; text-align:center;">
      <span class="badge badge-wallet">Keamanan BelanjaPay</span>
      <h2 style="font-size:1.3rem; margin-top:0.45rem;">Masukkan 6-Digit PIN</h2>
      <p id="pinModalSub" style="font-size:0.8rem; color:var(--color-muted); margin-top:0.25rem;">PIN Demo Default: <strong class="fig">123456</strong></p>
      <div id="pinDots" style="display:flex; justify-content:center; gap:0.65rem; margin:1.25rem 0;"></div>
      <div class="numpad-grid">
        <button type="button" class="numpad-key" onclick="pinTap('1')">1</button>
        <button type="button" class="numpad-key" onclick="pinTap('2')">2</button>
        <button type="button" class="numpad-key" onclick="pinTap('3')">3</button>
        <button type="button" class="numpad-key" onclick="pinTap('4')">4</button>
        <button type="button" class="numpad-key" onclick="pinTap('5')">5</button>
        <button type="button" class="numpad-key" onclick="pinTap('6')">6</button>
        <button type="button" class="numpad-key" onclick="pinTap('7')">7</button>
        <button type="button" class="numpad-key" onclick="pinTap('8')">8</button>
        <button type="button" class="numpad-key" onclick="pinTap('9')">9</button>
        <button type="button" class="numpad-key" onclick="closePinModal()" style="font-size:0.82rem;">Batal</button>
        <button type="button" class="numpad-key" onclick="pinTap('0')">0</button>
        <button type="button" class="numpad-key" onclick="pinBackspace()" style="font-size:0.9rem;">⌫</button>
      </div>
    </div>
  </div>

  <div id="app"></div>

  <script>
    let APP = ${json};
    let currentUserId = localStorage.getItem('belanjain_uid') || null;
    let currentPath = window.location.pathname || '/';
    let redirectAfterLogin = null;
    let maskBalance = false;
    let searchQuery = '';
    let activeCategory = 'ALL';
    let activeBrand = 'ALL';
    let catalogSort = 'relevance';
    let wishlistIds = JSON.parse(localStorage.getItem('belanjain_wish') || '["prd-001","prd-003"]');
    let stateCart = JSON.parse(localStorage.getItem('belanjain_cart') || '[{"productId":"prd-002","qty":1,"variant":"Hitam Obsidian"}]');
    let selectedShippingId = 'shp-2';
    let appliedCouponCode = 'BELANJAPAY75';
    let useBelanjaPayAtCheckout = true;
    let selectedPaymentMethod = 'BCA Virtual Account';
    let historyTypeFilter = 'all';
    let historyCatFilter = 'all';
    let sellerTab = 'OVERVIEW';
    let adminTab = 'KPI';

    // PIN Modal State
    let pinBuffer = '';
    let pendingPinCallback = null;

    function fmtIDR(n) {
      const sign = n < 0 ? '-' : '';
      return sign + 'Rp ' + Math.abs(Math.round(n)).toLocaleString('id-ID');
    }
    function escapeHtml(s) {
      return String(s || '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
    }
    function getCurrentUser() {
      if (!currentUserId) return null;
      return APP.users.find(u => u.id === currentUserId) || null;
    }
    function getUserWallet(uid) {
      if (!uid) return null;
      return APP.wallets.find(w => w.userId === uid) || null;
    }
    function persistLocal() {
      if (currentUserId) localStorage.setItem('belanjain_uid', currentUserId);
      else localStorage.removeItem('belanjain_uid');
      localStorage.setItem('belanjain_cart', JSON.stringify(stateCart));
      localStorage.setItem('belanjain_wish', JSON.stringify(wishlistIds));
    }
    function logoutUser() {
      currentUserId = null;
      persistLocal();
      showToast('Anda telah keluar dari akun.');
      nav('/login');
    }
    function showToast(msg) {
      document.getElementById('toastMsg').textContent = msg;
      document.getElementById('toastBox').style.display = 'block';
    }
    function nav(path) {
      currentPath = path;
      window.history.pushState({}, '', path);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      render();
    }
    function toggleMaskBalance() { maskBalance = !maskBalance; render(); }
    function doGlobalSearch() {
      const el = document.getElementById('globalSearchInput');
      searchQuery = el ? el.value.trim() : '';
      nav('/products');
    }
    function filterByCategory(slug) { activeCategory = slug; nav('/products'); }
    function openProductDetail(slug) { nav('/products/' + slug); }
    function toggleWishlist(pid) {
      if (wishlistIds.includes(pid)) wishlistIds = wishlistIds.filter(x => x !== pid);
      else wishlistIds.push(pid);
      persistLocal();
      render();
    }
    function addToCart(pid, qty, variant) {
      const existing = stateCart.find(c => c.productId === pid);
      if (existing) existing.qty += (qty || 1);
      else stateCart.push({ productId: pid, qty: qty || 1, variant: variant || 'Hitam Obsidian' });
      persistLocal();
      showToast('Produk ditambahkan ke keranjang belanja.');
      render();
    }
    function changeCartQty(idx, delta) {
      if (!stateCart[idx]) return;
      stateCart[idx].qty += delta;
      if (stateCart[idx].qty <= 0) stateCart.splice(idx, 1);
      persistLocal();
      render();
    }
    function quickLogin(uid, route) {
      currentUserId = uid;
      persistLocal();
      const u = getCurrentUser();
      showToast('Selamat datang, ' + u.name + ' (' + u.role.toUpperCase() + ')');
      const target = redirectAfterLogin || route || '/';
      redirectAfterLogin = null;
      nav(target);
    }
    function doManualLogin() {
      const em = (document.getElementById('loginEmail')?.value || '').trim().toLowerCase();
      const found = APP.users.find(u => u.email.toLowerCase() === em);
      if (!found) return showToast('Email tidak ditemukan. Gunakan salah satu Akun Demo di bawah.');
      const dest = found.role === 'admin' ? '/admin' : found.role === 'seller' ? '/seller' : '/';
      quickLogin(found.id, dest);
    }

    async function apiCall(payload) {
      const res = await fetch('/api/belanjain', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUserId, adminId: 'usr-16', ...payload })
      });
      const data = await res.json();
      if (data.ok) {
        if (data.state) APP = data.state;
        showToast(data.message || 'Berhasil diproses.');
        render();
      } else {
        showToast(data.error || 'Terjadi kesalahan.');
      }
      return data;
    }

    // PIN Modal Helpers
    function openPinModal(subtitle, onComplete) {
      pinBuffer = '';
      pendingPinCallback = onComplete;
      document.getElementById('pinModalSub').innerHTML = subtitle + ' • PIN Demo: <strong class="fig">123456</strong>';
      renderPinDots();
      document.getElementById('pinModal').style.display = 'flex';
    }
    function closePinModal() {
      document.getElementById('pinModal').style.display = 'none';
      pinBuffer = '';
      pendingPinCallback = null;
    }
    function renderPinDots() {
      document.getElementById('pinDots').innerHTML = Array.from({length: 6}, (_, i) =>
        \`<span style="width:14px; height:14px; border-radius:99px; border:2px solid var(--color-wallet); background:\${i < pinBuffer.length ? 'var(--color-wallet)' : 'transparent'};"></span>\`
      ).join('');
    }
    function pinTap(digit) {
      if (pinBuffer.length >= 6) return;
      pinBuffer += digit;
      renderPinDots();
      if (pinBuffer.length === 6 && pendingPinCallback) {
        const cb = pendingPinCallback;
        const code = pinBuffer;
        closePinModal();
        cb(code);
      }
    }
    function pinBackspace() { pinBuffer = pinBuffer.slice(0, -1); renderPinDots(); }

    // Flow Triggers
    function submitTopUpRequest() {
      apiCall({
        action: 'CREATE_TOPUP',
        amount: Number(document.getElementById('topupNominal').value),
        method: document.getElementById('topupMethod').value
      });
    }
    function simulateTopUpPaid(topupId) {
      apiCall({ action: 'CONFIRM_TOPUP', topupId });
    }
    function requestTransferWithPin() {
      const recipient = document.getElementById('trfRecipient').value;
      const amount = Number(document.getElementById('trfAmount').value);
      const note = document.getElementById('trfNote').value;
      openPinModal('Konfirmasi Transfer ' + fmtIDR(amount) + ' ke ' + recipient, (pin) => {
        apiCall({ action: 'TRANSFER_WALLET', recipient, amount, note, pin });
      });
    }
    function requestWithdrawWithPin() {
      const amount = Number(document.getElementById('wdwAmount').value);
      const bankId = document.getElementById('wdwBankId').value;
      openPinModal('Konfirmasi Withdraw ' + fmtIDR(amount), (pin) => {
        apiCall({ action: 'REQUEST_WITHDRAW', amount, bankId, pin });
      });
    }
    function changeWalletPin() {
      apiCall({
        action: 'CHANGE_PIN',
        oldPin: document.getElementById('oldPinInput').value,
        newPin: document.getElementById('newPinInput').value
      });
    }
    function changeDailyLimitWithPin() {
      const newLimit = Number(document.getElementById('newDailyLimit').value);
      openPinModal('Ubah Limit Harian ke ' + fmtIDR(newLimit), (pin) => {
        apiCall({ action: 'CHANGE_DAILY_LIMIT', newLimit, pin });
      });
    }
    function submitAdminAdjustment() {
      apiCall({
        action: 'ADMIN_ADJUST_WALLET',
        targetUserId: document.getElementById('adjUserId').value,
        type: document.getElementById('adjType').value,
        amount: Number(document.getElementById('adjAmount').value),
        reason: document.getElementById('adjReason').value
      });
    }
    function submitOrderCheckout(needsPin) {
      const shipObj = APP.shippingMethods.find(s => s.id === selectedShippingId) || APP.shippingMethods[0];
      const runOrder = async (pin) => {
        const res = await apiCall({
          action: 'CHECKOUT_ORDER',
          items: stateCart,
          shippingMethod: shipObj.name,
          shippingCost: shipObj.price,
          voucherCode: appliedCouponCode,
          paymentMethod: selectedPaymentMethod,
          useWallet: useBelanjaPayAtCheckout,
          pin
        });
        if (res.ok) {
          stateCart = [];
          persistLocal();
          nav('/account');
        }
      };
      if (needsPin) {
        openPinModal('Konfirmasi Pembayaran BelanjaPay', runOrder);
      } else {
        runOrder('');
      }
    }
    function printReceipt(txId) {
      const tx = APP.transactions.find(t => t.id === txId);
      if (!tx) return;
      const w = window.open('', '_blank', 'width=520,height=640');
      w.document.write(\`<html><head><title>Struk BelanjaPay \${tx.id}</title><style>body{font-family:monospace;padding:24px;line-height:1.6}</style></head><body><h2>BUKTI TRANSAKSI BELANJAPAY</h2><hr><p>ID Mutasi: \${tx.id}</p><p>Referensi: \${tx.reference}</p><p>Keterangan: \${tx.title}</p><p>Nominal: \${tx.type==='in'?'+':'-'}\${fmtIDR(tx.amount)}</p><p>Saldo Sebelum: \${fmtIDR(tx.balanceBefore)}</p><p>Saldo Sesudah: \${fmtIDR(tx.balanceAfter)}</p><p>Status: \${tx.status.toUpperCase()}</p><hr><button onclick="window.print()">Cetak / Simpan PDF</button></body></html>\`);
    }

    ${CLIENT_STOREFRONT_JS}
    ${CLIENT_WALLET_JS}
    ${CLIENT_DASHBOARDS_JS}

    const PROTECTED_PREFIXES = ['/wallet', '/cart', '/checkout', '/account', '/seller', '/admin'];

    function render() {
      const root = document.getElementById('app');
      const isProtected = PROTECTED_PREFIXES.some(p => currentPath === p || currentPath.startsWith(p + '/'));
      if (isProtected && !currentUserId) {
        redirectAfterLogin = currentPath;
        currentPath = '/login';
        window.history.replaceState({}, '', '/login');
        showToast('Silakan masuk terlebih dahulu untuk mengakses halaman tersebut.');
      }
      if (currentPath === '/login' || currentPath === '/register') root.innerHTML = renderLoginPage();
      else if (currentPath === '/products') root.innerHTML = renderCatalogPage(false);
      else if (currentPath === '/flash-sale') root.innerHTML = renderCatalogPage(true);
      else if (currentPath.startsWith('/products/')) root.innerHTML = renderProductDetailPage(currentPath.replace('/products/', ''));
      else if (currentPath === '/cart') root.innerHTML = renderCartAndCheckoutPage(false);
      else if (currentPath === '/checkout') root.innerHTML = renderCartAndCheckoutPage(true);
      else if (currentPath === '/wallet') root.innerHTML = renderWalletDashboardPage();
      else if (currentPath === '/wallet/topup') root.innerHTML = renderWalletTopUpPage();
      else if (currentPath === '/wallet/transfer') root.innerHTML = renderWalletTransferPage();
      else if (currentPath === '/wallet/withdraw') root.innerHTML = renderWalletWithdrawPage();
      else if (currentPath === '/wallet/history') root.innerHTML = renderWalletHistoryPage();
      else if (currentPath === '/wallet/security' || currentPath === '/wallet/pin') root.innerHTML = renderWalletSecurityPage();
      else if (currentPath === '/account' || currentPath === '/account/orders') root.innerHTML = renderCustomerAccountPage();
      else if (currentPath === '/seller') root.innerHTML = renderSellerDashboardPage();
      else if (currentPath === '/admin') root.innerHTML = renderAdminDashboardPage();
      else if (currentPath === '/promo') root.innerHTML = renderStaticInfoPage('promo');
      else if (currentPath === '/order/track') root.innerHTML = renderStaticInfoPage('track');
      else if (currentPath === '/faq') root.innerHTML = renderStaticInfoPage('faq');
      else root.innerHTML = renderHomePage();
    }

    window.addEventListener('popstate', () => { currentPath = window.location.pathname || '/'; render(); });
    render();
  </script>
</body>
</html>`;
}

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const server = http.createServer((req, res) => {
  const url = new URL(req.url || "/", `http://127.0.0.1:${PORT}`);
  if (url.pathname.startsWith("/images/")) {
    const safeName = path.basename(url.pathname);
    const imgPath = path.join(__dirname, "public", "images", safeName);
    if (fs.existsSync(imgPath)) {
      const mime = safeName.endsWith(".png") ? "image/png" : "image/jpeg";
      res.writeHead(200, { "Content-Type": mime, "Cache-Control": "public, max-age=86400" });
      fs.createReadStream(imgPath).pipe(res);
      return;
    }
  }
  if (url.pathname === "/api/belanjain" && req.method === "GET") {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ ok: true, state: buildBootstrapPayload() }));
    return;
  }
  if (url.pathname === "/api/belanjain" && req.method === "POST") {
    let raw = "";
    req.on("data", (c) => (raw += c));
    req.on("end", async () => {
      try {
        const result = handleApiAction(JSON.parse(raw || "{}"));
        if (result.ok) {
          await saveDatabaseState(state);
        }
        res.writeHead(result.ok ? 200 : 400, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ ...result, dbMode: getDbMode() }));
      } catch (err) {
        res.writeHead(500, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ ok: false, error: String(err) }));
      }
    });
    return;
  }
  res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
  res.end(renderHtmlShell());
});

server.listen(PORT, HOST, () => {
  console.log(`BelanjaIn + BelanjaPay siap di http://${HOST}:${PORT}`);
});
