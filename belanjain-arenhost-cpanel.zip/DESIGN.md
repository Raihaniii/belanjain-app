# BelanjaIn & BelanjaPay — Design System Specification (`DESIGN.md`)

> Sistem desain terkunci untuk platform E-Commerce Marketplace (**BelanjaIn**) dan Dompet Digital Terintegrasi (**BelanjaPay**) yang diselaraskan dengan **Google Stitch MCP** (`projects/12712644737387604654`, Design System `assets/1708632170226013066`), **Hallmark v2.0.0**, dan **Taste-Skill v2.5.1**.

## 1. Identitas Warna & Permukaan (Tokens `:root`)
- **Primary CTA (`--color-primary`):** `#FF5A1F` (Oranye Aksi BelanjaIn — tombol beli, checkout, flash sale)
- **Secondary / Ink (`--color-navy`):** `#111827` (Deep Navy — tipografi utama, sidebar, navigasi aktif)
- **BelanjaPay Vault (`--color-wallet`):** `#5B21B6` / `#4C1D95` (Deep Royal Plum — area kartu dompet digital, mutasi saldo, cashback 2%)
- **Info Accent (`--color-sky`):** `#0EA5E9` (Sky Blue — pelacakan kurir & badge informasi)
- **Semantic:** Success `#10B981` (uang masuk / lunas), Warning `#F59E0B` (pending / stok menipis), Danger `#EF4444` (uang keluar / ditolak / frozen)
- **Neutral Canvas:** Background `#F9FAFB`, Card `#FFFFFF`, Muted `#6B7280`, Border `#E5E7EB`

## 2. Tipografi & Angka Tabular
- **Heading (`--font-display`):** `Plus Jakarta Sans` (bobot 600–700, tracking `-0.025em`, *sentence case*)
- **Body (`--font-body`):** `Inter` (bobot 400–500, ukuran dasar `15px–16px`, line-height `1.55`)
- **Nominal Rupiah, Nomor Wallet & ID Mutasi (`--font-mono`):** `JetBrains Mono` dengan `font-variant-numeric: tabular-nums` agar seluruh angka nominal (`Rp 4.850.000`, `WLL-88291001`, `WLT-20261120-1001`) sejajar presisi.

## 3. Prinsip Anti-Slop & Aksesibilitas
1. Seluruh warna & font dideklarasikan di `:root` tanpa hardcode acak.
2. Transisi terbatas pada `transform` dan `opacity` (tanpa `transition: all`).
3. `:focus-visible` instan untuk navigasi keyboard & `prefers-reduced-motion: reduce`.
4. Saldo BelanjaPay mendukung toggle sembunyikan/tampilkan (`mask/unmask`) serta konfirmasi PIN 6 digit menggunakan NumPad besar untuk transaksi keluar.
