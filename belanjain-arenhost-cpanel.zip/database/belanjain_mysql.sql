-- ============================================================================
-- BELANJAIN x BELANJAPAY — MYSQL / MARIADB SCHEMA (SIAP IMPORT PHPMYADMIN ARENHOST)
-- Engine: InnoDB | Charset: utf8mb4_unicode_ci
-- ============================================================================

CREATE TABLE IF NOT EXISTS users (
  id VARCHAR(32) PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  phone VARCHAR(32) NOT NULL,
  role ENUM('customer', 'seller', 'admin') NOT NULL DEFAULT 'customer',
  store_name VARCHAR(140) NULL,
  join_date DATE NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS wallets (
  id VARCHAR(32) PRIMARY KEY,
  user_id VARCHAR(32) NOT NULL UNIQUE,
  wallet_number VARCHAR(32) NOT NULL UNIQUE,
  balance BIGINT NOT NULL DEFAULT 0,
  pending_balance BIGINT NOT NULL DEFAULT 0,
  pin_hash VARCHAR(64) NOT NULL DEFAULT '123456',
  pin_set TINYINT(1) NOT NULL DEFAULT 1,
  frozen TINYINT(1) NOT NULL DEFAULT 0,
  daily_limit BIGINT NOT NULL DEFAULT 10000000,
  used_today BIGINT NOT NULL DEFAULT 0,
  points INT NOT NULL DEFAULT 0,
  cashback_this_month BIGINT NOT NULL DEFAULT 0,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_wallet_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS wallet_transactions (
  id VARCHAR(40) PRIMARY KEY,
  wallet_id VARCHAR(32) NOT NULL,
  user_id VARCHAR(32) NOT NULL,
  type ENUM('in', 'out') NOT NULL,
  category ENUM('topup','payment','refund','transfer_in','transfer_out','withdraw','cashback','adjustment','release') NOT NULL,
  amount BIGINT NOT NULL,
  balance_before BIGINT NOT NULL,
  balance_after BIGINT NOT NULL,
  reference VARCHAR(64) NOT NULL,
  title VARCHAR(200) NOT NULL,
  note VARCHAR(255) NOT NULL,
  status ENUM('success','pending','failed') NOT NULL DEFAULT 'success',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_wtx_wallet (wallet_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS orders (
  id VARCHAR(40) PRIMARY KEY,
  user_id VARCHAR(32) NOT NULL,
  seller_id VARCHAR(32) NOT NULL,
  subtotal BIGINT NOT NULL,
  shipping_cost BIGINT NOT NULL DEFAULT 0,
  discount_amount BIGINT NOT NULL DEFAULT 0,
  total_amount BIGINT NOT NULL,
  wallet_paid_amount BIGINT NOT NULL DEFAULT 0,
  remaining_paid_amount BIGINT NOT NULL DEFAULT 0,
  payment_method VARCHAR(80) NOT NULL,
  cashback_earned BIGINT NOT NULL DEFAULT 0,
  status ENUM('pending','paid','processing','shipped','delivered','completed','cancelled','refunded') NOT NULL DEFAULT 'pending',
  awb_number VARCHAR(64) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_ord_user (user_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS topups (
  id VARCHAR(40) PRIMARY KEY,
  wallet_id VARCHAR(32) NOT NULL,
  user_id VARCHAR(32) NOT NULL,
  amount BIGINT NOT NULL,
  admin_fee BIGINT NOT NULL DEFAULT 0,
  total BIGINT NOT NULL,
  method VARCHAR(80) NOT NULL,
  status ENUM('pending','success','failed') NOT NULL DEFAULT 'pending',
  va_number VARCHAR(64) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS withdrawals (
  id VARCHAR(40) PRIMARY KEY,
  wallet_id VARCHAR(32) NOT NULL,
  user_id VARCHAR(32) NOT NULL,
  amount BIGINT NOT NULL,
  fee BIGINT NOT NULL DEFAULT 0,
  bank_name VARCHAR(80) NOT NULL,
  account_number VARCHAR(64) NOT NULL,
  account_holder VARCHAR(120) NOT NULL,
  status ENUM('pending','approved','rejected','paid') NOT NULL DEFAULT 'pending',
  reason VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabel Snapshot Sinkronisasi Otomatis Aplikasi Node.js -> MySQL
CREATE TABLE IF NOT EXISTS app_state_snapshot (
  state_key VARCHAR(64) PRIMARY KEY,
  payload LONGTEXT NOT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
