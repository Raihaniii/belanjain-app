# BelanjaIn + BelanjaPay — Platform E-Commerce & Dompet Digital Terintegrasi

Platform e-commerce marketplace full-stack (**BelanjaIn**) yang terintegrasi penuh dengan sistem dompet digital (**BelanjaPay**), dibangun dengan standar anti-slop (**Hallmark v2.0.0** + **Taste-Skill v2.5.1**) dan cetak biru **Google Stitch MCP** (`projects/12712644737387604654`).

## Cara Menjalankan
```bash
cd C:\Users\Lenovo\.gemini\antigravity\scratch\belanjain-belanjapay
npm install
npm run dev
```
Lalu buka **`http://127.0.0.1:3005`** di browser.

## Akun Demo (PIN Default BelanjaPay: `123456`)
| Role | Nama | Email | Password | Saldo Awal BelanjaPay |
| :--- | :--- | :--- | :--- | :--- |
| **Customer (Pembeli)** | Budi Santoso | `budi@belanjain.id` | `password123` | **Rp 4.850.000** |
| **Customer (Penerima Transfer)** | Siti Rahmawati | `siti@belanjain.id` | `password123` | **Rp 2.350.000** |
| **Seller (Penjual)** | Hendra Wijaya (*NusaTech Official*) | `seller@belanjain.id` | `password123` | **Rp 38.450.000** (+Pending Rp 6.250.000) |
| **Admin Platform** | Arif Budiman (*Super Admin*) | `admin@belanjain.id` | `password123` | **Rp 15.000.000** |

## Struktur Folder
- `/src/types/index.ts` — TypeScript strict interfaces (Zero `any`)
- `/src/data/` — 16 file data mock terpisah (`products.ts` 60 produk, `categories.ts` 12 kategori, `brands.ts` 10 brand, `customers.ts` 16 user, `wallets.ts` 16 wallet, `wallet-transactions.ts` 100 mutasi, `topups.ts` 20 top-up, `transfers.ts` 10 transfer, `withdrawals.ts` 8 withdraw, `wallet-adjustments.ts` 5 penyesuaian, `orders.ts` 25 order, `reviews.ts` 40 review, `promos.ts`, `coupons.ts`, `banners.ts`, `shipping-methods.ts`, `payment-methods.ts`, `faqs.ts`)
- `/src/lib/wallet-engine.ts` — Core transactional engine (Top-Up, Pay-with-Balance + Split Payment, Refund to Wallet, Atomic Transfer, Seller Withdraw, Admin Adjustment, 6-Digit PIN Lockout 3x/30m)
- `/scripts/verify-wallet.ts` — Pengujian otomatis end-to-end
- `/server-app.mjs` — Production-grade HTTP + REST API + Full Multi-Route Application Server
